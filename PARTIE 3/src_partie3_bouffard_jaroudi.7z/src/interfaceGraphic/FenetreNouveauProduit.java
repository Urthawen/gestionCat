package interfaceGraphic;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import controllers.productController;

public class FenetreNouveauProduit extends JFrame implements ActionListener {

	private JTextField txtPrixHT;
	private JTextField txtNom;
	private JTextField txtQte;
//	private JComboBox<String> combo;
	private JButton btValider;
	private productController pc;

//	public FenetreNouveauProduit(String[] lesCategories) {
	public FenetreNouveauProduit() {	
		pc = new productController();
		
		setTitle("Creation Produit");
		setBounds(500, 500, 200, 250);
		Container contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout());

		JLabel labNom = new JLabel("Nom produit");
		JLabel labPrixHT = new JLabel("Prix Hors Taxe");
		JLabel labQte = new JLabel("Quantit� en stock");
//		JLabel labCategorie = new JLabel("Categorie");
		contentPane.add(labNom);
		txtNom = new JTextField(15);
		contentPane.add(txtNom);
		contentPane.add(labPrixHT);
		txtPrixHT = new JTextField(15);
		contentPane.add(txtPrixHT);
		contentPane.add(labQte);
		txtQte = new JTextField(15);
		contentPane.add(txtQte);

//		combo = new JComboBox<String>(lesCategories);
//		combo.setPreferredSize(new Dimension(100, 20));
//		contentPane.add(labCategorie);
//		contentPane.add(combo);

		
		btValider = new JButton("Valider");
		contentPane.add(btValider);

		btValider.addActionListener(this);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		
		String dataNom = txtNom.getText();
		String dataPrixHT = txtPrixHT.getText();
		String dataQuantite = txtQte.getText();
		
		if(!dataNom.isEmpty() && !dataPrixHT.isEmpty() && !dataQuantite.isEmpty()) {
			if(isNumeric(dataPrixHT) && isNumeric(dataQuantite)) {
				String nom = dataNom;
				double prixHT = Double.parseDouble(dataPrixHT);
				int quantite = Integer.parseInt(dataQuantite);
				if(pc.addProduit(nom,prixHT,quantite)) {
					this.dispose();
					JOptionPane.showMessageDialog(null, "Product '"+nom+"' created", "New Product : Successfully", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
			}			
		}		
		JOptionPane.showMessageDialog(null, "Please, check your product information", "New Product : Error", JOptionPane.ERROR_MESSAGE);		
	}
	
	public static boolean isNumeric(String str)  
	{  
	  try  
	  {  
	    double d = Double.parseDouble(str);  
	  }  
	  catch(NumberFormatException nfe)  
	  {  
	    return false;  
	  }  
	  return true;  
	}

}