package interfaceGraphic;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import controllers.manageProductController;

public class FenetreAchat extends JFrame implements ActionListener {

	private JButton btAchat;
	private JTextField txtQuantite;
	private JComboBox<String> combo;
	private manageProductController mpc;
	public FenetreAchat() {

		mpc = new manageProductController();
		setTitle("Achat");
		setBounds(500, 500, 200, 125);
		Container contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout());
		btAchat = new JButton("Achat");
		txtQuantite = new JTextField(5);
		txtQuantite.setText("0");

		combo = new JComboBox<String>(mpc.getProducts());
		combo.setPreferredSize(new Dimension(100, 20));
		contentPane.add(new JLabel("Produit"));
		contentPane.add(combo);
		contentPane.add(new JLabel("Quantit� achet�e"));
		contentPane.add(txtQuantite);
		contentPane.add(btAchat);

		btAchat.addActionListener(this);

		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		
		String dataName = (String) combo.getSelectedItem();
		String dataQuantite = txtQuantite.getText();
		
		if(!dataName.isEmpty() && !dataQuantite.isEmpty()) {
			if(isNumeric(dataQuantite)) {
				int qte = Integer.parseInt(dataQuantite);
				if(qte>0 && mpc.buyStock(dataName, qte)) {
					this.dispose();			
					JOptionPane.showMessageDialog(null, qte+" '"+dataName+"' has been bought", "Buy Stock Product : Successfully", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
			}
		}
		JOptionPane.showMessageDialog(null, "Please, check your informations", "Buy Stock Product : Error", JOptionPane.ERROR_MESSAGE);	
		
	}
	
	public static boolean isNumeric(String str)  
	{  
	  try  
	  {  
	    double d = Double.parseDouble(str);  
	  }  
	  catch(NumberFormatException nfe)  
	  {  
	    return false;  
	  }  
	  return true;  
	}

}
