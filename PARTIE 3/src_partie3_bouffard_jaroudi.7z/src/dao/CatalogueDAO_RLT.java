package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import classMetier.Catalogue;
import classMetier.I_Catalogue;
import classMetier.I_Produit;
import classMetier.Produit;

public class CatalogueDAO_RLT implements CatalogueDAO{

	
	private ResultSet rs;
	
	private PreparedStatement ps_count;
	private PreparedStatement ps_listCatalogueWithProducts;
	private PreparedStatement ps_addCatalogue;
	private PreparedStatement ps_deleteCatalogue;
	private PreparedStatement ps_selectCatalogue;
	private PreparedStatement ps_getId;
	
	private Connection cn;
	
	
	public CatalogueDAO_RLT() {
		cn = ConnectionDB.getInstance();
		InitPrepareStatements();
	}

	private void InitPrepareStatements() {

		try {
			//Create a Product
			ps_count = cn.prepareStatement("SELECT COUNT(*) as rowCount FROM Catalogue", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);			

			ps_addCatalogue = cn.prepareStatement("INSERT INTO Catalogue (nomCatalogue) VALUES (?)", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

			ps_deleteCatalogue = cn.prepareStatement("DELETE FROM Catalogue WHERE nomCatalogue = ?", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			ps_selectCatalogue = cn.prepareStatement("SELECT * FROM Catalogue WHERE nomCatalogue = ?", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			
			//SELECT  COUNT(*) TotalCount, c.idCatalogue, c.nomCatalogue FROM Catalogue c INNER JOIN Produit p ON c.idCatalogue= p.catalogue GROUP   BY c.idCatalogue, c.nomCatalogue
			ps_listCatalogueWithProducts = cn.prepareStatement("SELECT nomCatalogue FROM Catalogue ORDER BY nomCatalogue ASC", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
 
			ps_getId = cn.prepareStatement("SELECT idCatalogue FROM Catalogue WHERE nomCatalogue = ?", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void create(String nom) {
		try {
			ps_addCatalogue.setString(1, nom);
			
			ps_addCatalogue.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	@Override
	public void delete(String nom) {
		try {
			ps_deleteCatalogue.setString(1, nom);
			
			ps_deleteCatalogue.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	@Override
	public void load(String name) {
		try {
			ps_selectCatalogue.setString(1, name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<String> readAll() {
		
		List<String> catalogues = 	new ArrayList<String>();
		
		try {
			rs = ps_listCatalogueWithProducts.executeQuery();
			
			while(rs.next()) {
				catalogues.add(rs.getString("nomCatalogue"));
			}
			
			if(catalogues.size()==0) {
				catalogues.add("Aucun catalogue cr��...");
			}
			
			return catalogues;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	@Override
	public int count() {

		try {
			rs = ps_count.executeQuery();
			 rs.next();
			 int rowCount = rs.getInt(1);
			return rowCount;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}

	@Override
	public int getId(String nom) {
		try {
			ps_getId.setString(1, nom);
			
			rs = ps_getId.executeQuery();
			rs.next();
			int idCatalogue = rs.getInt(1);
			return idCatalogue;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

}
