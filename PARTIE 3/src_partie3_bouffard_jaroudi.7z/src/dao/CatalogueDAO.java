package dao;

import java.util.List;

import classMetier.I_Catalogue;


public interface CatalogueDAO {
	void create(String nom);
	void delete(String nom);
	int count();
	int getId(String nom);
	
	void load(String name);
	List<String> readAll();
}
