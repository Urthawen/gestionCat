package dao;

import java.util.List;

import classMetier.I_Produit;

public interface ProduitDAO {
	void create(I_Produit Product);
	void update(I_Produit Product);
	void delete(I_Produit Product);
	
	I_Produit read(String name);
	List<I_Produit> readAll();
}
