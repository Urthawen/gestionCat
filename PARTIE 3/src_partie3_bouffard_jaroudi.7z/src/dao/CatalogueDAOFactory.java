package dao;

public class CatalogueDAOFactory extends DAOAbstractFactory{
	
	
	public static CatalogueDAO createCatalogueDAO() {
		switch (DAOName) {
		case "XML":
			return null;		
			
		case "RLT":
			return new CatalogueDAO_RLT();
		default:
			return null;
		}
	}
}
