package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDB {

	
	private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static final String DB_CONNECTION = "jdbc:oracle:thin:@162.38.222.149:1521:iut";
	private static final String DB_USER = "bouffardf";
	private static final String DB_PASSWORD = "1106033471V";
	

	private Connection cn;
	
	private static ConnectionDB instance;
	
	
	private ConnectionDB() {
		InitDriver();
		Connection();
	}
	
	public static Connection getInstance() {
		if(instance==null)
			instance = new ConnectionDB();
		return instance.cn;
	}
	
	private void Connection() {
		try {
			this.cn = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	private void InitDriver() {
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
