package dao;

public abstract class DAOAbstractFactory {	
	protected static final String DAOName = "RLT";
}
