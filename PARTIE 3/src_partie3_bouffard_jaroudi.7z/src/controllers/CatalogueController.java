package controllers;


import java.util.ArrayList;
import java.util.List;

import classMetier.Catalogue;
import classMetier.I_Catalogue;
import dao.CatalogueDAO;
import dao.CatalogueDAOFactory;

public class CatalogueController {


	Catalogue cat;
	private static CatalogueDAO CDAO;
	
	public CatalogueController(){
		CDAO = CatalogueDAOFactory.createCatalogueDAO();
	}
	
	public void selectCatalogue(String name) {
		cat = Catalogue.getInstance();
		cat.setNomCatalogue(name);
		cat.setId(CDAO.getId(name));
	}
	
	public boolean createCatalogue(String name) {
		if(!name.isEmpty() && name.length() <= 50) {
			CDAO.create(name);
			return true;
		}		
		return false;
	}
	
	public void deleteCatalogue(String name) {
		CDAO.delete(name);
	}
	
	public int getNumberOfCatalogue() {
		return CDAO.count();
	}
	
	public String[] listCatalogueWithProducts() {
		List<String> catalogues = 	new ArrayList<String>();
		catalogues = CDAO.readAll();
		
		String data[] = new String[catalogues.size()];
		
		for(int i=0; i < catalogues.size();i++) {
			data[i] = catalogues.get(i);
		}
		
		return data;
	}
}
