package dao;

public class ProduitDAOFactory {
	
	private static final String DAOName = "XML";
	
	public static ProduitDAO createProduitDAO() {
		switch (DAOName) {
		case "XML":
			return new Adp_ProduitDAO_XML();
		
		case "RLT":
			return new ProduitDAO_RLT();
		default:
			return null;
		}
	}
}
