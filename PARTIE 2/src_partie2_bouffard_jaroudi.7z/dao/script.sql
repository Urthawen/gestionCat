DROP TABLE Produit CASCADE CONSTRAINTS;

CREATE TABLE Produit(
  idProduit CHAR(5),
  nomProduit VARCHAR(15),
  prixHT NUMBER(*,2),
  quantite NUMBER(5),
CONSTRAINT pk_Catalogue PRIMARY KEY (idProduit));


CREATE SEQUENCE product_seq START WITH 1;

CREATE OR REPLACE TRIGGER insert_product_trigger
BEFORE INSERT ON Produit
FOR EACH ROW

BEGIN
  SELECT product_seq.NEXTVAL
  INTO   :new.idProduit
  FROM   dual;
END;

INSERT INTO Produit (nomProduit, prixHT, quantite) VALUES ('Orange', 2.99, 15);
INSERT INTO Produit (nomProduit, prixHT, quantite) VALUES ('Pomme', 1.56, 23);
INSERT INTO Produit (nomProduit, prixHT, quantite) VALUES ('Cerise', 0.56, 18);
INSERT INTO Produit (nomProduit, prixHT, quantite) VALUES ('Banane', 1.24, 32);

COMMIT;
