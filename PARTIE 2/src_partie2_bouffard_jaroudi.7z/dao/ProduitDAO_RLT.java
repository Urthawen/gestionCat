package dao;

import java.util.ArrayList;
import java.util.List;

import classMetier.I_Produit;
import classMetier.Produit;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProduitDAO_RLT implements ProduitDAO {
	
	private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static final String DB_CONNECTION = "jdbc:oracle:thin:@162.38.222.149:1521:iut";
	private static final String DB_USER = "bouffardf";
	private static final String DB_PASSWORD = "1106033471V";
	
	private ResultSet rs;
	private Connection cn;
	
	private PreparedStatement ps_selectAll;
	private PreparedStatement ps_create;
	private PreparedStatement ps_update;
	private PreparedStatement ps_read;
	private PreparedStatement ps_delete;
	
	
	public ProduitDAO_RLT() {
		InitProduitDAO_RLT();		
	}

	private void InitProduitDAO_RLT() {
		InitDriver();
		ConnectionDB();	
		InitPrepareStatements();
	}

	private void InitPrepareStatements() {

		try {
			//Select all Products
			ps_selectAll = cn.prepareStatement("SELECT * FROM Produit",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			//Create a Product
			ps_create = cn.prepareStatement("INSERT INTO Produit (nomProduit, prixHT, quantite) VALUES (?,?,?)", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

			//Update an existing Product
			ps_update = cn.prepareStatement("UPDATE Produit SET quantite = ? WHERE nomProduit = ?", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			//Read a specific Product (Param:Product Name)
			ps_read = cn.prepareStatement("SELECT * FROM Produit WHERE nomProduit = ?", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			//Delete an existing Product
			ps_delete = cn.prepareStatement("DELETE FROM Produit WHERE nomProduit = ?", ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void ConnectionDB() {
		try {
			this.cn = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	private void InitDriver() {
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void create(I_Produit Product) {
		String nomProduit = Product.getNom();
		double prixHT = Product.getPrixUnitaireHT();
		int quantite = Product.getQuantite();
		
		try {
			ps_create.setString(1, nomProduit);
			ps_create.setDouble(2, prixHT);
			ps_create.setInt(3, quantite);
			
			ps_create.executeUpdate();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(I_Produit Product) {
		
		String nomProduit = Product.getNom();
		int quantite = Product.getQuantite();
		
		try {
			ps_update.setInt(1, quantite);
			ps_update.setString(2, nomProduit);
			
			ps_update.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void delete(I_Produit Product) {
		
		String nomProduit = Product.getNom();
		
		try {
			ps_delete.setString(1, nomProduit );
			
			ps_delete.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public I_Produit read(String name) {
		
		try {
			ps_read.setString(1, name);
			rs = ps_read.executeQuery();
			
			while(rs.next()) {
				String nomProduit = rs.getString("nomProduit");
				double prixHT = rs.getDouble("prixHT");
				int quantite = rs.getInt("quantite");
				I_Produit product = new Produit(nomProduit, prixHT, quantite);
				
				return product;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<I_Produit> readAll() {
		
		List<I_Produit> products = 	new ArrayList<I_Produit>();
		
		try {
			rs = ps_selectAll.executeQuery();
			while(rs.next()) {
				String name = rs.getString("nomProduit");
				double prixHT = rs.getDouble("prixHT");
				int quantite = rs.getInt("quantite");
				I_Produit product = new Produit(name,prixHT,quantite);
				products.add(product);
			}
			
			return products;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
