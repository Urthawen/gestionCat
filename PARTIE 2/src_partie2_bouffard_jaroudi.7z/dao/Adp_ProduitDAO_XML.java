package dao;

import java.util.List;

import classMetier.I_Produit;

public class Adp_ProduitDAO_XML implements ProduitDAO{
	
	private ProduitDAO_XML PDAO_XML;
	
	public Adp_ProduitDAO_XML() {
		this.PDAO_XML = new ProduitDAO_XML();
	}

	@Override
	public void create(I_Produit Product) {
		this.PDAO_XML.creer(Product);
	}

	@Override
	public void update(I_Produit Product) {
		this.PDAO_XML.maj(Product);		
	}

	@Override
	public void delete(I_Produit Product) {
		this.PDAO_XML.supprimer(Product);
	}

	@Override
	public List<I_Produit> readAll() {
		return this.PDAO_XML.lireTous();
	}

	@Override
	public I_Produit read(String name) {
		return this.PDAO_XML.lire(name);
	}

}
