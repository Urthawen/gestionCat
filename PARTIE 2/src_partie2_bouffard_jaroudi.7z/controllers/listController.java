package controllers;
import classMetier.Catalogue;
import dao.ProduitDAO;
import dao.ProduitDAOFactory;

public class listController {
	
	Catalogue cat;
	private static ProduitDAO PDAO;
	
	public listController() {
		cat = Catalogue.getInstance();
		PDAO = ProduitDAOFactory.createProduitDAO();
	}
	
	public  String getAffichage() {		
		cat.clear();
		cat.addProduits(PDAO.readAll());
		return cat.toString();
	}

}
