package controllers;

import classMetier.Catalogue;

import classMetier.I_Produit;
import classMetier.Produit;
import dao.ProduitDAO;
import dao.ProduitDAOFactory;

public class productController {
	
	Catalogue cat;
	ProduitDAO PDAO;
	
	public productController() {
		cat = Catalogue.getInstance();
		PDAO = ProduitDAOFactory.createProduitDAO();
	}

	public boolean addProduit(String nom, double prixHT, int quantite) {
		if(cat.addProduit(nom, prixHT, quantite)) {
			I_Produit product = new Produit(nom, prixHT, quantite);
			PDAO.create(product);
			return true;
		}else {
			return false;
		}	
	}
	
	public boolean deleteProduit(String nom) {
		
		I_Produit product = cat.lookingForProduct(nom);
		
		if(cat.removeProduit(nom)) {
			PDAO.delete(product);
			return true;
		}else {
			return false;
		}
	}
	
	public String[] getProducts() {
		cat.clear();
		cat.addProduits(PDAO.readAll());
		return cat.getNomProduits();
	}
}
