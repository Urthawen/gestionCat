package controllers;

import classMetier.Catalogue;
import classMetier.I_Produit;
import dao.ProduitDAO;
import dao.ProduitDAOFactory;

public class manageProductController {

	Catalogue cat;
	private static ProduitDAO PDAO;
	
	public manageProductController() {
		cat = Catalogue.getInstance();
		PDAO = ProduitDAOFactory.createProduitDAO();
	}
	
	public boolean buyStock(String nom, int qte) {
		I_Produit product = cat.lookingForProduct(nom);
		
		if(product!=null) {
			product.ajouter(qte);
			PDAO.update(product);
		}
		return cat.acheterStock(nom, qte);
	}
	
	public boolean sellStock(String nom, int qte) {
		I_Produit product = cat.lookingForProduct(nom);
		
		if(product!=null) {
			if(cat.vendreStock(nom, qte)) {
			product.enlever(qte);
			PDAO.update(product);	
			return true;
			}
		}
		
		return false;
	}
	
	public String[] getProducts() {
		cat.clear();
		cat.addProduits(PDAO.readAll());
		return cat.getNomProduits();
	}
}
